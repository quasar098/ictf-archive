## Challenge
Your mission, should you choose to accept it, is to write three programs in ICICLE: cat, gcd, and sort. Python implementations of these can be found in `impl.py`. All programs must run in 30 seconds or less.

NOTE: This is using ICICLE v2, which means that the `readf`, `writef`, and `exec` commands are not available.

### Cat
Write a program that reads input from the user, and prints the input, followed by a newline (i.e. the behavior when entering `cat` at the command line with no arguments). This continues until the user enters `exit` as the input, at which point the program exits.

### GCD
Write a program that reads two ints from the user, and finds their greatest common divisor. Numbers will be between 1 and 1,000,000,000 inclusive.

### Sort
Write a program that reads an int denoting the length of the list. It then reads that many ints from the user, and prints them in ascending order, separated by spaces. A trailing or leading space is acceptable.

## Golf (Bonus Challenge)
There's one more aspect to this challenge, and that's code golf! Whoever has the shortest sorting code at the end of the month wins one month of Discord Nitro, courtesy of yours truly. "Shortest" is defined as the least number of lines, excluding empty lines, labels, and comments. This is implemented by `checkLen` in `harness.py`.

Ties will be broken in order of submission time - the remote will keep track of the shortest submission, and it will only declare a new winner if the new submission is strictly smaller than the current shortest program (and not if they are the same length).

For the record, this code golf mini-competition is being organized by me (puzzler7) only, and it will have no bearing on the usual ICTF competition.