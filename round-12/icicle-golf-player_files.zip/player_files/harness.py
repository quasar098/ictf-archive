#!/usr/bin/env python3

from icicle import *
from base64 import b64decode
import random
from math import gcd
import time

def timeElapsed(t):
    diff = time.time()-t
    m = int(diff)//60
    s = round(diff%60, 3)
    print("\tTime elapsed: %dm %0.3fs\n"%(m,s))
    return time.time()

def test(inp, out, prog):
    try:
        vm = VM(program=prog, testing=1, inp=inp, limit=30)
        vm.run()
        return vm.output_buffer.strip() == out.strip()
    except ICICLEException as e:
        print("ICICLE error occurred:", str(e))
        return False

def checkLen(prog):
    prog = [i.split('#')[0].strip() for i in prog.strip().split("\n")]
    prog = [i for i in prog if len(i) > 0 and (i[-1] != ':' or ' ' in i)]
    return len(prog)
    
def printWinner():
    try:
        with open("winner.txt", 'r') as w, open("shortest.s", 'r') as p:
            winner = w.read()
            shortlen = checkLen(p.read()) 
            print(f"The current winner of the code golf mini-competition is {winner}, with a score of {shortlen} lines!")
            print(f"Congratulations, {winner}!")
            print()
            print("Whoever has the shortest sort code at the end of the month wins one month of Discord Nitro, courtesy of yours truly.")
    except IOError as e:
        print("Something went wrong when trying to determine the code golf winner.")
        print("Please ping puzzler7 or board members on Discord.")
    print()

def printFlag():
    print('You made it!')
    with open("flag.txt", 'r') as f:
        print("The flag is", f.read())

def checkNewWinner(prog):
    try:
        with open("shortest.s", 'r') as s:
            currentlen = checkLen(s.read())
            newlen = checkLen(prog)
    except Exception as e:
        return
    if newlen < currentlen:
        print(f"Congratulations! You are the new code golf winner, with a score of {newlen} lines!")
        print("Whoever has the shortest sort code at the end of the month wins one month of Discord Nitro, courtesy of yours truly.")
        print()
        while True:
            name = input("Please enter your name for the leaderboard: ")
            confirm = input(f"Are you sure you want your name to be {name}? (y/n) ")
            if 'y' in confirm.lower():
                break
        with open("winner.txt", 'w') as w, open("shortest.s", 'w') as s:
            w.write(name)
            s.write(prog)

def readProg():
    prog = input("Please enter your ICICLE code, converted to base64: ")
    return b64decode(prog.encode('UTF8')).decode('UTF8') 

def randomStr(l):
    return ''.join([chr(random.randint(32,128)) for i in range(l)])

def testCat():
    print("Now testing the 'cat' program.")
    prog = readProg()
    print("Testing...")
    for i in range(50):
        inp = [randomStr(random.randint(1, 100)) for i in range(100)]+['exit']
        out = "\n".join(inp[:-1])
        res = test(inp, out, prog)
        if not res:
            print("Failed!")
            exit()
    print("Passed the 'cat' test!")

def testGCD():
    print("Now testing the 'gcd' program.")
    prog = readProg()
    print("Testing...")
    for i in range(1000):
        inp = [random.randint(1,1000000000) for i in range(2)]
        out = str(gcd(inp[0], inp[1]))
        res = test(inp, out, prog)
        if not res:
            print("Failed with input", inp)
            exit()
    print("Passed the 'gcd' test!")

def testSort():
    print("Now testing the 'sort' program.")
    prog = readProg()
    
    lens = [100, 500, 1000, 1000, 1000]
    msg = ["random", "random", "random", "reverse", "sorted"]
    inps = [[lens[i]]+[random.randint(1,1000000000) for i in range(lens[i])] for i in range(5)]
    inps[3] = [1000]+list(range(1,1001))[::-1]
    inps[4] = [1000]+list(range(1,1001))

    s = time.time()
    for i in range(5):
        print(f"Test {i+1}: {msg[i]} with length {lens[i]}")
        inp = inps[i]
        out = ' '.join([str(i) for i in sorted(inp[1:])])
        res = test(inp, out, prog)
        if not res:
            print("Failed!")
            exit()
        print(f"Passed test {i+1}")
        s = timeElapsed(s)

    print("Passed the 'sort' test!")
    checkNewWinner(prog)

if __name__ == '__main__':
    printWinner()
    testCat()
    testGCD()
    testSort()
    printFlag()