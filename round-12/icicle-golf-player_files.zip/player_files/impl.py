#!/usr/bin/env python3

def cat():
    while True:
        x = input()
        if x == 'exit':
            break
        print(x)

def gcd():
    a = int(input())
    b = int(input())
    from math import gcd
    print(gcd(a, b))

def sort():
    num = int(input())
    lst = []
    for i in range(num):
        lst.append(int(input())

    print(' '.join(sorted(lst)))