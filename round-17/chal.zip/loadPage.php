<?php
	include($_GET["filename"]);
?>