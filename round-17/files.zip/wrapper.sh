#!/bin/bash
export FLAG=$(sed 's/{\|}/_/g' /app/flag.txt)
java -classpath "$(printf %s: /app/*.jar)" Server