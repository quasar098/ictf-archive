import org.apache.logging.log4j.*;
import org.apache.logging.log4j.core.config.Configurator;
import java.util.Scanner;

public class Server {

  private static final Logger logger = LogManager.getLogger(Server.class);

  public static void main(String argv[]) {
    try{
      System.out.print("Hi! What's your name? ");
      Scanner inp = new Scanner(System.in);
      String name = inp.nextLine();
      logger.info("New name logged: "+name);
      System.out.println("Hi "+name+"! I hope you have a great day.");
      System.exit(0);
    } catch (Exception e){
      System.exit(-1);
    }
  }
}