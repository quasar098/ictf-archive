#include <stdio.h>
#include <stdlib.h>

int main() {
  long idx;
  char* buf = malloc(0x1000000);
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  while (1) {
    printf("offset> ");
    scanf("%ld%*c", &idx);
    printf("value> ");
    scanf("%ld%*c", &buf[idx]);
  }
}

int win() {
  system("/bin/sh");
}
