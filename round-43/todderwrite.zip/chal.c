#include <stdio.h>
#include <stdlib.h>

int main() {
  long idx;
  char* buf = malloc(0x1000000);
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
  while (1) {
    printf("offset> ");
    scanf("%lu%*c", &idx);
    printf("value> ");
    scanf("%c%*c", &buf[idx]);
    if (idx == 1337) {
      return;
    }
  }
}

