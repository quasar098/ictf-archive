#!/bin/sh

ADMIN_UUID=$(node /app/src/cli.js admin "Hey guys, as i mentioned i really do not like the new Uint8Array API for node, and if you also are a believer of buffer supremacy give me this flag once we meet $FLAG" | jq .uuid)
FRIEND_MESSAGE="Psst, i heard you guys are looking for Admin, here is some help: $ADMIN_UUID"

function friend_helps {
    # Friend is ignored every time ;()
    FRIEND_USER=$(node /app/src/cli.js friend "$FRIEND_MESSAGE")
}

while true; do
    friend_helps
    sleep 30
done