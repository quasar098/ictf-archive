# UInt8Array Bad

JavaScript, or more accuratly V8 has in many years had the best binary abstraction in the `Buffer` type, 
it is one of the reasons why node.js is so dang fast, due to its super optimized allocation algorithms, (sometimes even beating out manually allocated memory in C++).

However these days the `Uint8Array` is the new hotness, but its API is so trash, at least it has full compatibility with the browser, but it is still a pain to use, so i much prefer to use `Buffer` in node.js, lets chat about it!
