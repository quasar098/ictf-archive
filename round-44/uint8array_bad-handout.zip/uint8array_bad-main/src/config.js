const crypto = require('crypto');

module.exports = {
    port: 8080,
    // This is not the flag, but nice try ;)
    jwt_secret: `jctf{${crypto.randomBytes(32).toString('base64')}}`,
}