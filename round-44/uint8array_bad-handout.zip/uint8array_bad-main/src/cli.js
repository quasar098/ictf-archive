const io = require('socket.io-client');

const serverURL = 'http://localhost:8080'; // Replace 'YOUR_PORT' with the port your server is running on.

// Check if a message argument is provided
if (process.argv.length < 4) {
    console.log("Usage: node cli.js <username> <message>");
    console.error("Please provide a message argument.");
    process.exit(1);
}

// wait 2 seconds for server to start
setTimeout(() => {
    const socket = io(serverURL, {
        query: {
            username: process.argv[2],
        }
    });
    
    socket.on('connect', () => {
        console.error("Connected to server");
        // Send the message to the server
        socket.emit('message', process.argv[3]);
        console.error("Sent message");
    
        setTimeout(() => {
            socket.disconnect();
            process.exit(0);
        }, 500);
    });

    socket.on('user', user => {
        console.log(JSON.stringify(user));
    });
}, 2000);