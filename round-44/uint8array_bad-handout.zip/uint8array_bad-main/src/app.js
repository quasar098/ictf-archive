const fs = require('fs');
const uuid = require('uuid');
const path = require('path');
const jwt = require('jsonwebtoken');

const { port, jwt_secret } = require('./config');
const { createServer } = require('http');
const { Server } = require('socket.io');


const httpServer = createServer(
    (req, res) => {
        // Serve static index.html        
        res.writeHead(200, { 'Content-Type': 'text/html' });

        fs.readFile(path.join(__dirname, '../public/index.html'), (err, data) => {
            if (err) {
                res.end(err);
            } else {
                res.end(data);
            }
        });
    }
);

const io = new Server(httpServer);

class User {
    constructor(uuid) {
        this.uuid = uuid;
        this.username = null;
        this.lastSeen = Date.now();
        this.lastMessage = null;
        this.savedMessages = null;
    }

    get jwt() {
        return jwt.sign({
            uuid: this.uuid,
            iat: Math.floor(Date.now() / 1000) - 30,
            exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 7,
        }, jwt_secret, { algorithm: 'HS256' });
    }
}

const users = {};

io.on('connection', socket => {
    let userUUID = null;
    let token = socket.handshake.query.token;
    let username = socket.handshake.query.username;

    if (token === "null") token = null;
    if (username === "null") username = null;
    
    // Try to find the user
    if (token) {
        try {
            if (!token) {
                throw new Error('No token provided');
            }

            const jwtData = jwt.verify(token, jwt_secret);

            if (!users[jwtData.uuid]) {
                throw new Error('User not found');
            }

            userUUID = jwtData.uuid;
        } catch (err) {
            socket.emit('error', 'Invalid token');
            socket.disconnect(true);
            return;
        }
    }


    // Create a new user
    if (!users[userUUID]) {
        userUUID = uuid.v4();
        users[userUUID] = new User(userUUID);
        users[userUUID].username = username ?? `User ${userUUID}`;

        socket.emit('user', {
            username: users[userUUID].username,
            uuid: userUUID,
            token: users[userUUID].jwt
        });
    }


    socket.on('message', message => {
        if (typeof message !== 'string') {
            socket.emit('error', 'Invalid message');
            return;
        }

        const timestamp = Date.now();

        users[userUUID].lastMessage = message;
        users[userUUID].lastSeen = timestamp;

        // Admin messages are secret.
        if (users[userUUID].username === "admin") {
            return;
        }

        socket.broadcast.emit('message', {
            username: users[userUUID].username,
            timestamp,
            message,
        });
    });

    socket.on('updateUsername', username => {
        if (typeof username !== 'string') {
            socket.emit('error', 'Invalid username');
            return;
        }

        users[userUUID].username = username;
    });

    // Debug test
    socket.on('whoami', () => {
        socket.emit('whoami', users[userUUID]);
    });

    socket.on('saveMessages', messages => {
        try {
            users[userUUID].savedMessages = Buffer.from(messages, 'base64');
        } catch (err) {
            socket.emit('error', 'Invalid messages');
        }
    });

    socket.on('getMessages', messageId => {
        if (!users[userUUID].savedMessages) {
            return;
        }

        if (!messageId) {
            socket.emit('messages', users[userUUID].savedMessages.toString('base64'));
            return;
        }
        
        socket.emit('messages', users[userUUID].savedMessages[messageId]);
    });
});


httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on port ${port}`);
});

