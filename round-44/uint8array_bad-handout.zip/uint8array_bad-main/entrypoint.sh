#!/bin/sh
/bin/sh setup.sh &
node /app/src/app.js
