from flask import (
    Flask,
    request,
    send_file,
    redirect,
    render_template,
    flash,
    session,
    g,
)
from werkzeug.routing import Rule
from uuid import uuid4
import os
import sqlite3

FLAG_ID = str(uuid4())

app = Flask(__name__)
app.secret_key = os.urandom(16).hex()


DEFAULT_TEMPLATE = """
{method} {path} HTTP/1.1
{headers}

{body}
"""[
    1:
]


def db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect("/tmp/db.sqlite3")
        db.row_factory = sqlite3.Row
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


@app.before_first_request
def db_init():
    db = sqlite3.connect("/tmp/db.sqlite3")
    cursor = db.cursor()
    cursor.executescript(
        """
    CREATE TABLE IF NOT EXISTS request (
        id TEXT,
        request TEXT,
        time DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(id, time)
    );
    CREATE TABLE IF NOT EXISTS request_template (
        id TEXT PRIMARY KEY,
        template TEXT
    );
    """
    )
    cursor.execute(
        "INSERT OR IGNORE INTO request (id, request) VALUES (?, ?)",
        (FLAG_ID, open("flag.txt").read()),
    )
    cursor.execute(
        "INSERT OR IGNORE INTO request_template (id, template) VALUES (?, ?)",
        (FLAG_ID, DEFAULT_TEMPLATE),
    )
    db.commit()
    db.close()


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/new")
def new():
    session["uuid"] = str(uuid4())
    cursor = db().cursor()
    cursor.execute(
        "INSERT INTO request_template (id, template) VALUES (?, ?)",
        (session["uuid"], DEFAULT_TEMPLATE),
    )
    db().commit()
    return redirect("/dashboard")


@app.get("/dashboard")
def dashboard():
    if "uuid" not in session:
        return redirect("/")
    cursor = db().cursor()
    requests = cursor.execute(
        "SELECT * FROM request WHERE id = ? ORDER BY time DESC", (session["uuid"],)
    ).fetchall()
    template = cursor.execute(
        "SELECT template FROM request_template WHERE id = ?", (session["uuid"],)
    ).fetchone()["template"]
    return render_template(
        "dashboard.html", uuid=session["uuid"], requests=requests, template=template
    )


@app.post("/edit_template")
def edit_template():
    if "uuid" not in session:
        return redirect("/")
    cursor = db().cursor()
    cursor.execute(
        "UPDATE request_template SET template = ? WHERE id = ?",
        (request.form["template"], session["uuid"]),
    )
    db().commit()
    flash("Template updated")
    return redirect("/dashboard")


app.url_map.add(Rule("/r/<uuid>", endpoint="record"))


@app.endpoint("record")
def record(uuid):
    if uuid == FLAG_ID:
        return "I am a teapot!", 418
    cursor = db().cursor()
    result = cursor.execute(
        "SELECT template FROM request_template WHERE id = ?", (uuid,)
    ).fetchone()
    if not result:
        return "Not Found", 404
    body = request.get_data()
    try:
        body = body.decode()
    except UnicodeDecodeError:
        body = "[binary data]"
    req = result["template"].format(
        method=request.method, path=request.path, headers=request.headers, body=body
    )
    cursor.execute("INSERT INTO request (id, request) VALUES (?, ?)", (uuid, req))
    db().commit()
    return ""


if __name__ == "__main__":
    app.run(port=8000)
